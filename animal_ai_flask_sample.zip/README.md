# 似てる動物AI Flaskアプリ

## 起動方法

```bash
pip install -r requirements.txt
python app.py
```

## 機能
- スマホで写真を撮ってアップロード
- ランダムに似ている動物を表示（仮）
- Renderで公開可能
